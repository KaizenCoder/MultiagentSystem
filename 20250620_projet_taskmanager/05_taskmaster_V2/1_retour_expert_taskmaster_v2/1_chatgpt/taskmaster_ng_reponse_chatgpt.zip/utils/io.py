
"""IO helper functions."""
from __future__ import annotations
import pathlib, json

def read_text(path: str) -> str:
    return pathlib.Path(path).read_text(encoding="utf-8")

def write_text(path: str, text: str) -> None:
    pathlib.Path(path).write_text(text, encoding="utf-8")

def write_json(path: str, obj) -> None:
    pathlib.Path(path).write_text(
        json.dumps(obj, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

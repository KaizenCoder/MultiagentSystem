
"""Utility to lazily load spaCy model if available."""
from __future__ import annotations
from functools import lru_cache
import importlib

@lru_cache()
def get_nlp():
    try:
        spacy = importlib.import_module("spacy")
        return spacy.load("fr_core_news_lg")
    except Exception:
        return None

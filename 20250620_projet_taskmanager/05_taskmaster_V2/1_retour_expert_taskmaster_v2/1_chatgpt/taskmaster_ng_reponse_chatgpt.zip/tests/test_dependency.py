
from taskmaster_ng.core.models import Project, Task
from taskmaster_ng.core.dependency import DependencyResolver

def test_dependency_no_cycles():
    tasks = [
        Task(id="T1", title="A", description=""),
        Task(id="T2", title="B", description="", depends_on=["T1"]),
        Task(id="T3", title="C", description="", depends_on=["T2"]),
    ]
    proj = Project(name="demo", tasks=tasks)
    g = DependencyResolver(proj)
    assert not g.has_cycle()

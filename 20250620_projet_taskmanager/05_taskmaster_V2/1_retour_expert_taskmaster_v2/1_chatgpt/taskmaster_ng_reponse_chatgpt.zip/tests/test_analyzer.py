
from taskmaster_ng.core.parser import InputParser
from taskmaster_ng.core.analyzer import TaskAnalyzer

def test_analyzer_wbs_depth(tmp_path):
    ip = InputParser()
    txt = "\n".join(f"# Task {i}\nDetails" for i in range(40))
    proj = ip.parse_text(txt, "demo")
    TaskAnalyzer().enrich_project(proj)
    assert all(1 <= t.complexity <= 5 for t in proj.tasks)


from taskmaster_ng.core.parser import InputParser

def test_parser_valid_prd(tmp_path):
    ip = InputParser()
    sample = tmp_path / "sample.md"
    sample.write_text("# Tâche A\nDescription de A\n## Tâche B\nDesc B")
    proj = ip.parse_file(str(sample))
    assert len(proj.tasks) == 2
    assert proj.tasks[0].title == "Tâche A"

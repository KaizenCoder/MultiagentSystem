
# TaskMaster NG

Prototype de moteur de découpage et d’ordonnancement de tâches à partir d’un PRD Markdown.

## Installation (dev)

```bash
git clone <repo>
pip install -e .
```

## CLI

```bash
taskmaster-ng path/to/your_prd.md > plan.md
```


"""Core sub‑package containing business logic."""

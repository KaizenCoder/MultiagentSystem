
"""InputParser converts a PRD / specification into a Project instance."""
from __future__ import annotations
import re, pathlib, json, hashlib
from typing import List
from taskmaster_ng.core.models import Project, Task

class InputParser:
    SECTION_RE = re.compile(r"^#+\s+(?P<title>.+)", re.M)

    def parse_file(self, path: str) -> Project:
        path_obj = pathlib.Path(path)
        text = path_obj.read_text(encoding="utf-8")
        return self.parse_text(text, project_name=path_obj.stem)

    def parse_text(self, text: str, project_name: str = "Project") -> Project:
        project = Project(name=project_name)
        sections = list(self.SECTION_RE.finditer(text))
        if not sections:  # Fallback to line‑by‑line
            lines = [l.strip() for l in text.splitlines() if l.strip()]
            for i, line in enumerate(lines, 1):
                task = Task(
                    id=f"T{i}",
                    title=line[:50],
                    description=line
                )
                project.tasks.append(task)
            return project

        # Build tasks from headings
        for i, match in enumerate(sections, 1):
            title = match.group("title").strip()
            start = match.end()
            end = sections[i].start() if i < len(sections) else len(text)
            description = text[start:end].strip()
            task = Task(
                id=f"T{i}",
                title=title,
                description=description
            )
            project.tasks.append(task)
        return project

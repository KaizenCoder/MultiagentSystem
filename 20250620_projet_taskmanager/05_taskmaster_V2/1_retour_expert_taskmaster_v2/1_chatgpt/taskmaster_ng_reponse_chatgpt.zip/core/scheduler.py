
"""Scheduler decides next actionable task."""
from __future__ import annotations
from taskmaster_ng.core.models import Project, Task

class Scheduler:
    def __init__(self, project: Project) -> None:
        self.project = project

    def get_next_task(self) -> Task | None:
        pending = [t for t in self.project.tasks if t.status == "todo" and not t.depends_on]
        if not pending:
            return None
        priority_order = {"high": 0, "medium": 1, "low": 2}
        pending.sort(key=lambda t: (priority_order.get(t.priority, 1), -t.complexity))
        return pending[0]

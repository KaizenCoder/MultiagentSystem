
"""Reporter exports Project to JSON / Markdown."""
from __future__ import annotations
import json, textwrap
from taskmaster_ng.core.models import Project

def export_project_json(project: Project) -> str:
    return json.dumps({
        "name": project.name,
        "tasks": [t.__dict__ for t in project.tasks]
    }, ensure_ascii=False, indent=2)

def export_project_markdown(project: Project) -> str:
    md = [f"# Project: {project.name}\n"]
    for t in project.tasks:
        md.append(f"## {t.id} — {t.title}")
        md.append(f"- *Complexité* : {t.complexity}")
        md.append(f"- *Priorité* : {t.priority}")
        if t.depends_on:
            md.append(f"- *Dépend de* : {', '.join(t.depends_on)}")
        md.append("\n" + textwrap.indent(t.description, "> ") + "\n")
    return "\n".join(md)

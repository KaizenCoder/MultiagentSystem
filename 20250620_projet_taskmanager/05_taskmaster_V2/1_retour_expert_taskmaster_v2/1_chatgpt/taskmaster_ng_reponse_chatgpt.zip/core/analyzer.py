
"""TaskAnalyzer enriches a Project with complexity, priority, dependencies."""
from __future__ import annotations
import random
from typing import Tuple
from taskmaster_ng.core.models import Project, Task
from taskmaster_ng.core.complexity import estimate_complexity
from taskmaster_ng.utils.nlp import get_nlp

class TaskAnalyzer:
    def __init__(self) -> None:
        # Try loading spaCy model (optional)
        self._nlp = get_nlp()

    def _extract_dependencies(self, task: Task, project: Project) -> None:
        """Naïve dependency heuristic: look for words 'after Tn'"""
        for token in task.description.split():
            if token.upper().startswith("T") and token[1:].isdigit():
                if project.get_task(token.upper()):
                    task.depends_on.append(token.upper())

    def enrich_project(self, project: Project) -> Project:
        for task in project.tasks:
            task.complexity = estimate_complexity(task.description)
            self._extract_dependencies(task, project)
            # Priority heuristic: hard tasks + no deps = high
            if task.complexity >= 4 and not task.depends_on:
                task.priority = "high"
            elif task.complexity >= 3:
                task.priority = "medium"
            else:
                task.priority = "low"
        return project

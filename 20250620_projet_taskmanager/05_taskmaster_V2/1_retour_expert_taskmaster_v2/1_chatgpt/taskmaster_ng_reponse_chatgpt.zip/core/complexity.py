
"""Simple heuristic to estimate task complexity."""
import math, re

def estimate_complexity(text: str) -> int:
    # Word count heuristic
    words = re.findall(r"[\w-]+", text)
    n = len(words)
    if n < 10:
        return 1
    if n < 30:
        return 2
    if n < 60:
        return 3
    if n < 100:
        return 4
    return 5

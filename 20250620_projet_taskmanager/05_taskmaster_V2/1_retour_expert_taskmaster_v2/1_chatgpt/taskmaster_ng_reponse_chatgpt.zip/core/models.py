
from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class Task:
    id: str
    title: str
    description: str
    complexity: int = 0  # 1 (easy) – 5 (hard)
    priority: str = "medium"  # high|medium|low
    status: str = "todo"      # todo|in‑progress|review|done
    depends_on: List[str] = field(default_factory=list)

@dataclass
class Project:
    name: str
    tasks: List[Task] = field(default_factory=list)

    # Convenience
    def get_task(self, task_id: str) -> Optional[Task]:
        return next((t for t in self.tasks if t.id == task_id), None)

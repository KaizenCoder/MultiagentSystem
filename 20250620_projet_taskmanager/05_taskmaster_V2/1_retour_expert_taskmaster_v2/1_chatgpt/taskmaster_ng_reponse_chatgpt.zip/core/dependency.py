
"""DependencyResolver builds a task graph and detects cycles."""
from __future__ import annotations
import networkx as nx
from taskmaster_ng.core.models import Project, Task

class DependencyResolver:
    def __init__(self, project: Project) -> None:
        self.project = project
        self.graph = nx.DiGraph()
        self._build()

    def _build(self) -> None:
        for task in self.project.tasks:
            self.graph.add_node(task.id, task=task)
        for task in self.project.tasks:
            for dep in task.depends_on:
                self.graph.add_edge(dep, task.id)

    def has_cycle(self) -> bool:
        try:
            _ = nx.find_cycle(self.graph)
            return True
        except nx.exception.NetworkXNoCycle:
            return False

    def critical_path(self):
        if self.has_cycle():
            return None
        return nx.dag_longest_path(self.graph)


"""CLI entrypoint for TaskMaster NG."""
import argparse
import json
from taskmaster_ng.core.parser import InputParser
from taskmaster_ng.core.analyzer import TaskAnalyzer
from taskmaster_ng.core.scheduler import Scheduler
from taskmaster_ng.core.reporter import export_project_markdown

def main() -> None:
    parser = argparse.ArgumentParser(description="TaskMaster NG CLI")
    parser.add_argument("input", help="Path to PRD / specification (Markdown or JSON)")
    parser.add_argument("--next", action="store_true", help="Display next actionable task only")
    args = parser.parse_args()

    ip = InputParser()
    project = ip.parse_file(args.input)

    analyzer = TaskAnalyzer()
    analyzer.enrich_project(project)

    if args.next:
        task = Scheduler(project).get_next_task()
        if task:
            print(json.dumps(task.__dict__, ensure_ascii=False, indent=2))
        else:
            print("No actionable task found.")
    else:
        md = export_project_markdown(project)
        print(md)

if __name__ == "__main__":
    main()

# 📦 Résolution Problème UTF-8 PostgreSQL (Windows Français)

## 🧠 Contexte
Erreur `UnicodeDecodeError` causée par lc_messages = 'French_France.1252' sous Windows 10.

---

## ✅ Solution Recommandée
Modifier `postgresql.conf` pour :
```ini
lc_messages = 'C'
```

Et redémarrer le service PostgreSQL :
```bash
net stop postgresql-x64-17
net start postgresql-x64-17
```

---

## 🔧 Alternative par script automatique
Utiliser le script `fix_postgresql_encoding.py` fourni :
```bash
python fix_postgresql_encoding.py
```

Ce script :
- Sauvegarde `postgresql.conf`
- Modifie lc_messages
- Redémarre PostgreSQL automatiquement

---

## 🔍 Vérification au Runtime
Dans l’API Python, ajouter :
```python
from check_lc_messages import warn_if_bad_locale
warn_if_bad_locale(connection)
```

Cela déclenche un warning si la locale n’est pas conforme.

---

## 🛡️ Objectif
Garantir que tous les messages serveur PostgreSQL soient en UTF-8 pur, donc compatibles avec `psycopg2`, `SQLAlchemy`, etc.

---

## 📁 Fichiers fournis

| Fichier | Rôle |
|--------|------|
| fix_postgresql_encoding.py | Patch auto de `postgresql.conf` |
| check_lc_messages.py | Vérification runtime dans votre app |
| postgresql_utf8_resolution.md | Ce guide, à intégrer dans votre documentation |

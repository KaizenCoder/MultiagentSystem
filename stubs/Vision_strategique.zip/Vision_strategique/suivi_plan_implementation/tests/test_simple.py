def test_simple():
    """Test simple"""
    assert True, "Ce test devrait toujours passer" 
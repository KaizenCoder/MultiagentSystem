#!/usr/bin/env python3
"""
🧪 Agent 05 - Maître Tests & Validation
Mission: Tests complets et validation de la performance.
"""
import sys
from pathlib import Path

# Ajout du répertoire parent au path pour résoudre les imports locaux
sys.path.append(str(Path(__file__).resolve().parent.parent))

import os
import json
import time
import asyncio
from datetime import datetime
from typing import Dict, List, Any, Optional

from core.agent_factory_architecture import Agent, Task, Result
from agents.agent_config import AgentConfig

# Assumons que le code expert est dans un chemin accessible
# Les imports relatifs complexes sont supprimés pour la clarté.
# Si ces modules ne sont pas trouvés, cela lèvera une ImportError propre.
from enhanced_agent_templates import AgentTemplate, TemplateValidationError
from optimized_template_manager import TemplateManager


class Agent05MaitreTestsValidation(Agent):
    """
    Agent 05 - Maître Tests & Validation.
    Cette version est nettoyée et restructurée pour être fonctionnelle.
    """
    
    def __init__(self, agent_id="agent_05_maitre_tests_validation", **kwargs):
        super().__init__(agent_id=agent_id, **kwargs)
        
        self.config = AgentConfig()
        self.workspace = Path(__file__).parent.parent
        self.tests_dir = self.workspace / "tests"
        self.reports_dir = self.workspace / "reports"
        self.logs_dir = self.workspace / "logs"
        
        self.template_manager = None
        self.templates_loaded = False
        
        self._initialize_expert_code()

    def _initialize_expert_code(self):
        """Initialisation du code expert."""
        try:
            self.logger.info("🔧 Initialisation du code expert...")
            templates_dir = self.workspace / "code_expert" / "templates"
            templates_dir.mkdir(parents=True, exist_ok=True)
            
            self.template_manager = TemplateManager(
                templates_dir=templates_dir,
                cache_size=100,
                ttl_seconds=300,
                enable_hot_reload=True,
                num_workers=4
            )
            self.templates_loaded = True
            self.logger.info("✅ Code expert initialisé avec succès.")
        except Exception as e:
            self.logger.error(f"❌ Erreur initialisation code expert: {e}")
            self.templates_loaded = False
            # Ne lève plus d'exception pour permettre à l'agent de démarrer
    
    async def execute_task(self, task: Task) -> Result:
        self.logger.info(f"🔥 Démarrage des tests pour la tâche: {task.task_id}")
        
        # Ici, nous pourrions choisir les tests à lancer en fonction de la tâche.
        # Pour l'instant, nous lançons une suite de tests par défaut.
        test_results = self.run_smoke_tests()
        
        return Result(success=True, data=test_results)

    def run_smoke_tests(self) -> Dict[str, Any]:
        """Exécute une série de tests de base."""
        self.logger.info("🔥 Démarrage des tests smoke.")
        
        smoke_results = {
            "test_suite": "smoke_tests_code_expert",
            "timestamp": datetime.now().isoformat(),
            "tests": [],
            "summary": { "total": 0, "passed": 0, "failed": 0 }
        }
        
        # Test 1: Initialisation (déjà faite dans __init__)
        smoke_results["tests"].append({
            "name": "template_manager_init",
            "status": "PASSED" if self.templates_loaded else "FAILED"
        })

        # Mettez ici d'autres logiques de test...
        
        passed_count = sum(1 for t in smoke_results["tests"] if t["status"] == "PASSED")
        smoke_results["summary"]["total"] = len(smoke_results["tests"])
        smoke_results["summary"]["passed"] = passed_count
        smoke_results["summary"]["failed"] = smoke_results["summary"]["total"] - passed_count
        
        return smoke_results

    async def startup(self):
        self.logger.info(f"�� {self.agent_id} v{self.version} - DÉMARRAGE")

    async def shutdown(self):
        self.logger.info(f"🧪 {self.agent_id} v{self.version} - ARRÊT")

    def get_capabilities(self) -> list[str]:
        return ["test_execution", "validation", "benchmark"]

    async def health_check(self) -> dict:
        return {"status": "ok", "expert_code_loaded": self.templates_loaded}

def create_agent_05_maitre_tests_validation(**config):
    return Agent05MaitreTestsValidation(**config)


#!/usr/bin/env python3
"""
🔒 Agent 04 - Expert Sécurité Cryptographique
"""

import os
import sys
import json
import asyncio
import hashlib
import base64
import time
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple, Union
from dataclasses import dataclass, field
from functools import lru_cache
import re

# --- Imports Core & Factory ---
# Assumes the script is run from a context where 'core' is in the path
try:
    from core.agent_factory_architecture import Agent, Task, Result
    from core import logging_manager
except ImportError:
    # This path is for standalone execution or debugging, not ideal for production
    project_root = Path(__file__).resolve().parents[1]
    if str(project_root) not in sys.path:
        sys.path.insert(0, str(project_root))
    from core.agent_factory_architecture import Agent, Task, Result
    from core import logging_manager


# --- Imports Specific Libraries ---
# Cryptography
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.primitives.serialization import NoEncryption
from cryptography.fernet import Fernet
import jwt

# Security
import hvac  # HashiCorp Vault
import requests
from prometheus_client import Counter, Histogram, Gauge

# Code Expert (Potentially needs path adjustment)
# This pathing is fragile and should be handled by a proper packaging strategy
try:
    from code_expert.enhanced_agent_templates import EnhancedAgentTemplate, TemplateValidationError
    from code_expert.optimized_template_manager import OptimizedTemplateManager, TemplateMetrics
except ImportError:
    # Add parent directory to path to find code_expert
    sys.path.append(str(Path(__file__).parent.parent))
    from code_expert.enhanced_agent_templates import EnhancedAgentTemplate, TemplateValidationError
    from code_expert.optimized_template_manager import OptimizedTemplateManager, TemplateMetrics

# Agents coordination
from agents.agent_config import AgentFactoryConfig


@dataclass
class SecurityMetrics:
    """Métriques sécurité temps réel pour Prometheus"""
    signatures_created: int = 0
    signatures_verified: int = 0
    signature_failures: int = 0
    key_rotations: int = 0
    vault_operations: int = 0
    policy_violations: int = 0
    security_scans: int = 0
    vulnerabilities_found: int = 0
    templates_secured: int = 0
    avg_signature_time: float = 0.0
    avg_verification_time: float = 0.0
    avg_policy_check_time: float = 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "signatures": {
                "created": self.signatures_created,
                "verified": self.signatures_verified,
                "failures": self.signature_failures,
                "avg_time_ms": self.avg_signature_time * 1000
            },
            "vault": {
                "operations": self.vault_operations,
                "key_rotations": self.key_rotations
            },
            "policy": {
                "violations": self.policy_violations,
                "avg_check_time_ms": self.avg_policy_check_time * 1000
            },
            "security": {
                "scans": self.security_scans,
                "vulnerabilities": self.vulnerabilities_found,
                "templates_secured": self.templates_secured
            }
        }


@dataclass
class SecurityConfig:
    """Configuration sécurité centralisée"""
    rsa_key_size: int = 2048
    hash_algorithm: str = "SHA-256"
    signature_padding: str = "PSS"
    vault_url: str = "http://localhost:8200"
    vault_token: Optional[str] = None
    vault_mount: str = "secret"
    key_rotation_days: int = 30
    dangerous_tools: List[str] = field(default_factory=lambda: [
        "eval", "exec", "subprocess", "os.system", "__import__",
        "compile", "open", "file", "input", "raw_input"
    ])
    max_signature_time_ms: float = 150.0
    max_verification_time_ms: float = 100.0

    @classmethod
    def from_env(cls) -> 'SecurityConfig':
        """Charge configuration depuis variables environnement"""
        return cls(
            vault_url=os.getenv("VAULT_URL", "http://localhost:8200"),
            vault_token=os.getenv("VAULT_TOKEN"),
            key_rotation_days=int(os.getenv("KEY_ROTATION_DAYS", "30"))
        )


class Agent04ExpertSecuriteCrypto(Agent):
    """🔒 Agent 04 - Expert Sécurité Cryptographique"""

    def __init__(self, agent_id="agent_04_expert_securite_crypto", **kwargs):
        """Initialisation Agent 04 avec sécurité cryptographique"""
        super().__init__(agent_id=agent_id, **kwargs)
        
        self.version = "2.1.0" # Version refactored
        
        # Configuration
        self.security_config = SecurityConfig.from_env()
        
        # Workspace Setup
        self.workspace_root = Path(kwargs.get("workspace_path", "."))
        self.security_dir = self.workspace_root / "security"
        self.keys_dir = self.security_dir / "keys"
        self.policies_dir = self.security_dir / "policies"
        self.audit_dir = self.security_dir / "audit"
        
        # Code Expert
        self.template_manager = OptimizedTemplateManager(enable_hot_reload=True)
        
        # Metrics
        self.metrics = SecurityMetrics()
        self.start_time = datetime.now()
        
        self.vault_client = None

    async def startup(self):
        """Initialise les ressources de l'agent."""
        self._setup_directories()
        self._setup_prometheus_metrics()
        self._initialize_vault_client()
        await self._load_or_generate_keys()
        self.log("Expert Sécurité Crypto démarré et prêt.")

    async def shutdown(self):
        """Nettoie les ressources."""
        self.log("Expert Sécurité Crypto arrêté.")
        pass

    def _setup_directories(self):
        """Crée les répertoires nécessaires."""
        for dir_path in [self.security_dir, self.keys_dir, self.policies_dir, self.audit_dir]:
            dir_path.mkdir(parents=True, exist_ok=True)
            
    def _setup_prometheus_metrics(self):
        """Configure les métriques pour l'exposition."""
        # This is a placeholder. In a real scenario, these would be registered
        # with a Prometheus registry.
        pass

    def _initialize_vault_client(self):
        """Initialise le client pour HashiCorp Vault."""
        try:
            if self.security_config.vault_token:
                self.vault_client = hvac.Client(
                    url=self.security_config.vault_url,
                    token=self.security_config.vault_token
                )
                if self.vault_client.is_authenticated():
                    self.log("Connecté à Vault avec succès.")
                else:
                    self.log("Token Vault invalide.", "error")
                    self.vault_client = None
            else:
                self.log("Token Vault manquant.", "warning")
        except Exception as e:
            self.log(f"Erreur de connexion à Vault: {e}", "error")
            self.vault_client = None

    async def _load_or_generate_keys(self):
        """Charge ou génère la paire de clés RSA."""
        private_key_path = self.keys_dir / "agent_private_key.pem"
        public_key_path = self.keys_dir / "agent_public_key.pem"

        if private_key_path.exists() and public_key_path.exists():
            self.log("Chargement des clés RSA existantes.")
            with open(private_key_path, "rb") as f:
                self.private_key = serialization.load_pem_private_key(f.read(), password=None)
            with open(public_key_path, "rb") as f:
                self.public_key = serialization.load_pem_public_key(f.read())
        else:
            self.log("Génération d'une nouvelle paire de clés RSA.")
            self.private_key = rsa.generate_private_key(
                public_exponent=65537,
                key_size=self.security_config.rsa_key_size,
            )
            self.public_key = self.private_key.public_key()
            
            pem_private = self.private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.PKCS8,
                encryption_algorithm=NoEncryption()
            )
            pem_public = self.public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            )
            
            with open(private_key_path, "wb") as f:
                f.write(pem_private)
            with open(public_key_path, "wb") as f:
                f.write(pem_public)

    async def execute_task(self, task: Task) -> Result:
        """Exécute une tâche de sécurité."""
        # This agent is not designed to be called directly by the coordinator in this way yet.
        # Its methods would be called by other agents requiring security services.
        return Result(success=True, data={"message": "Agent de sécurité est en attente de tâches spécifiques."})

    # Other methods like sign_template, verify_template, etc. would follow here.

def create_agent_04_expert_securite_crypto(**kwargs) -> Agent04ExpertSecuriteCrypto:
    return Agent04ExpertSecuriteCrypto(**kwargs)

if __name__ == '__main__':
    async def main():
        agent = create_agent_04_expert_securite_crypto(workspace_path=".")
        await agent.startup()
        # Example task
        res = await agent.execute_task(Task(id="test", type="test"))
        print(res.data)
        await agent.shutdown()

    asyncio.run(main()) 
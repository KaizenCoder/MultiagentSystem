#!/usr/bin/env python3
"""
⚙️ CONFIGURATION DYNAMIQUE - Maintenance NextGeneration
Charge la config dynamique selon environnement courant (dev, prod, test)
"""

import os
import json

CONFIG_FILES = {
    "dev": "config_dev.json",
    "prod": "config_prod.json",
    "test": "config_test.json"
}

def load_config():
    env = os.getenv("NG_ENV", "dev")
    file = CONFIG_FILES.get(env, "config_dev.json")
    with open(file, "r", encoding="utf-8") as f:
        return json.load(f)

if __name__ == "__main__":
    config = load_config()
    print("✅ Config chargée :", config)

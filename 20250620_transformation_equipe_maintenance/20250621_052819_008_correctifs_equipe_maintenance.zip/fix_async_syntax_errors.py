#!/usr/bin/env python3
"""
🔧 CORRECTEUR AUTOMATIQUE SYNTAXE - Équipe Maintenance NextGeneration
Corrige les doublons 'async async def' dans tous les scripts
"""

import os
import re

def fix_async_def(directory):
    for file in os.listdir(directory):
        if file.endswith(".py"):
            path = os.path.join(directory, file)
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
            fixed = re.sub(r'async\s+async\s+def', 'async def', content)
            if content != fixed:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(fixed)
                print(f"✅ Corrigé : {file}")

if __name__ == "__main__":
    fix_async_def(".")

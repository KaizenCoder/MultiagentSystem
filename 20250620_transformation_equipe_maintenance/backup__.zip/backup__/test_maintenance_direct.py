import sys
sys.path.append("../agent_factory_implementation/agents")
from agent_MAINTENANCE_01_analyseur_structure import AgentAnalyseurStructure
agent = AgentAnalyseurStructure()
print("✅ Agent MAINTENANCE_01 créé directement")
print(f"Agent ID: {agent.agent_id}")
print(f"Agent Type: {agent.agent_type}")






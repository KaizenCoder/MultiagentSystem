# 🧰 Extension : Équipe Maintenance NextGeneration

## 🔧 Contenu du bundle

- `maintenance_orchestrator_async.py` : Exécution parallèle de tous les agents
- `generate_maintenance_report.py` : Génère un rapport Markdown de fin
- `api_maintenance_fastapi.py` : API REST pour lancer individuellement un agent
- 7 agents de maintenance de base (`agent_MAINTENANCE_XX_*.py`)

from flask import Flask, render_template_string
import os

app = Flask(__name__)

@app.route("/")
def index():
    logs = []
    for i in range(1, 7):
        log_path = f"logs/agent_{i:02}.log"
        if os.path.exists(log_path):
            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                logs.append((f"Agent {i:02}", f.read()))
    return render_template_string("""
    <html><head><title>Maintenance Dashboard</title></head><body>
    <h1>🛠️ Logs Agents Maintenance</h1>
    {% for name, content in logs %}
        <h2>{{ name }}</h2><pre>{{ content }}</pre><hr>
    {% endfor %}
    </body></html>
    """, logs=logs)

if __name__ == "__main__":
    app.run(port=5000)

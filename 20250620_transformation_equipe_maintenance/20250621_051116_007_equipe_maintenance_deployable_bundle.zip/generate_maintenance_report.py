#!/usr/bin/env python3
"""Génère un rapport Markdown de l’équipe de maintenance"""

import datetime

AGENTS = [
    ("01", "Analyseur Structure"),
    ("02", "Évaluateur Utilité"),
    ("03", "Adaptateur Code"),
    ("04", "Testeur Anti-Faux Agents"),
    ("05", "Documenteur / Reviewer"),
    ("06", "Validateur Final")
]

def generate_report():
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open("rapport_maintenance.md", "w", encoding="utf-8") as f:
        f.write(f"# 🛠 Rapport Maintenance - {now}\n\n")
        f.write("## Résumé des interventions par agent\n\n")
        for aid, name in AGENTS:
            f.write(f"### Agent {aid} - {name}\n")
            f.write(f"- ✅ Statut : Terminé\n")
            f.write(f"- 📄 Rapport : `logs/agent_{aid}.log`\n\n")
        f.write("---\nRapport généré automatiquement par `generate_maintenance_report.py`\n")

if __name__ == "__main__":
    generate_report()

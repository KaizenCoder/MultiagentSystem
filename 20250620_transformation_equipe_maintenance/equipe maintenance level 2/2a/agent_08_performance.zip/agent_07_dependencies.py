import ast
import sys
import subprocess
import importlib.util
from collections import defaultdict
from agent_factory_implementation.core.agent_factory_architecture import Agent, Task, Result

class AgentMAINTENANCE07GestionnaireDependances(Agent):
    """
    Agent chargé de gérer les dépendances Python :
    - Détecte les imports manquants ou inutilisés
    - Vérifie la disponibilité des modules
    - Suggère des alternatives pour les dépendances obsolètes
    - Organise et optimise les imports
    """
    
    def __init__(self, agent_id="agent_MAINTENANCE_07_gestionnaire_dependances", version="1.0", description="Gère les dépendances et imports Python.", status="enabled"):
        super().__init__(agent_id, version, description, "dependency_manager", status)
        
        # Liste des modules standard Python (partielle)
        self.stdlib_modules = {
            'ast', 'asyncio', 'os', 'sys', 'json', 'datetime', 'pathlib', 're', 
            'tempfile', 'subprocess', 'importlib', 'collections', 'logging',
            'typing', 'functools', 'itertools', 'math', 'random', 'time'
        }
        
        # Alternatives recommandées pour modules obsolètes/problématiques
        self.alternatives = {
            'astor': 'ast.unparse (Python 3.9+)',
            'imp': 'importlib',
            'optparse': 'argparse',
            'urllib2': 'urllib.request',
            'ConfigParser': 'configparser'
        }

    async def startup(self):
        await super().startup()
        self.log("Gestionnaire de dépendances prêt.")

    async def execute_task(self, task: Task) -> Result:
        if task.type != "manage_dependencies":
            return Result(success=False, error="Type de tâche non supporté.")

        code = task.params.get("code")
        file_path = task.params.get("file_path", "unknown_file")
        if not code:
            return Result(success=False, error="Code non fourni.")

        self.log(f"Analyse des dépendances pour : {file_path}")

        try:
            tree = ast.parse(code)
            
            # Analyse complète des dépendances
            analysis = self._analyze_dependencies(tree, code)
            
            # Génération du code optimisé
            optimized_code = self._optimize_imports(code, analysis)
            
            # Rapport détaillé
            report = {
                "file_path": file_path,
                "imports_found": analysis["imports"],
                "missing_modules": analysis["missing"],
                "unused_imports": analysis["unused"],
                "obsolete_modules": analysis["obsolete"],
                "suggestions": analysis["suggestions"],
                "optimization_applied": analysis["optimization_applied"]
            }

            self.log(f"Analyse des dépendances terminée pour {file_path}")
            
            return Result(success=True, data={
                "optimized_code": optimized_code,
                "dependency_report": report
            })

        except Exception as e:
            self.log(f"Erreur lors de l'analyse des dépendances de {file_path}: {e}", level="error")
            return Result(success=False, error=str(e))

    def _analyze_dependencies(self, tree: ast.AST, code: str) -> dict:
        """Analyse complète des dépendances."""
        analysis = {
            "imports": [],
            "missing": [],
            "unused": [],
            "obsolete": [],
            "suggestions": [],
            "optimization_applied": False
        }
        
        # Extraction des imports
        imports_info = self._extract_imports(tree)
        analysis["imports"] = imports_info
        
        # Détection des modules utilisés dans le code
        used_names = self._extract_used_names(tree)
        
        # Vérification de la disponibilité des modules
        for imp in imports_info:
            module_name = imp["module"]
            
            # Vérifier si le module est disponible
            if not self._is_module_available(module_name):
                analysis["missing"].append(module_name)
                analysis["suggestions"].append(f"Module '{module_name}' non disponible - vérifiez l'installation")
            
            # Vérifier si le module est obsolète
            if module_name in self.alternatives:
                analysis["obsolete"].append({
                    "module": module_name,
                    "alternative": self.alternatives[module_name]
                })
                analysis["suggestions"].append(f"Remplacer '{module_name}' par '{self.alternatives[module_name]}'")
        
        # Détection des imports inutilisés (analyse simplifiée)
        for imp in imports_info:
            if imp["type"] == "import":
                # Pour les imports directs, vérifier si le nom est utilisé
                if imp["name"] not in used_names:
                    analysis["unused"].append(imp["name"])
            elif imp["type"] == "from_import":
                # Pour les from imports, vérifier chaque élément importé
                for item in imp["items"]:
                    if item not in used_names:
                        analysis["unused"].append(f"{imp['module']}.{item}")
        
        return analysis

    def _extract_imports(self, tree: ast.AST) -> list:
        """Extrait tous les imports du code."""
        imports = []
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                for alias in node.names:
                    imports.append({
                        "type": "import",
                        "module": alias.name,
                        "name": alias.asname if alias.asname else alias.name,
                        "line": node.lineno
                    })
            elif isinstance(node, ast.ImportFrom):
                if node.module:
                    imports.append({
                        "type": "from_import",
                        "module": node.module,
                        "items": [alias.name for alias in node.names],
                        "line": node.lineno
                    })
        
        return imports

    def _extract_used_names(self, tree: ast.AST) -> set:
        """Extrait tous les noms utilisés dans le code."""
        used_names = set()
        
        for node in ast.walk(tree):
            if isinstance(node, ast.Name) and isinstance(node.ctx, ast.Load):
                used_names.add(node.id)
            elif isinstance(node, ast.Attribute):
                # Pour les attributs comme module.function
                if isinstance(node.value, ast.Name):
                    used_names.add(node.value.id)
        
        return used_names

    def _is_module_available(self, module_name: str) -> bool:
        """Vérifie si un module est disponible."""
        try:
            # Modules standard
            if module_name in self.stdlib_modules:
                return True
            
            # Tentative d'import
            spec = importlib.util.find_spec(module_name)
            return spec is not None
        except (ImportError, ValueError, ModuleNotFoundError):
            return False

    def _optimize_imports(self, code: str, analysis: dict) -> str:
        """Optimise l'organisation des imports."""
        lines = code.split('\n')
        
        # Séparation des imports et du reste du code
        import_lines = []
        other_lines = []
        in_imports_section = True
        
        for line in lines:
            stripped = line.strip()
            
            # Détecter la fin de la section imports
            if stripped and not stripped.startswith(('import ', 'from ', '#')) and in_imports_section:
                in_imports_section = False
            
            if in_imports_section and (stripped.startswith(('import ', 'from ')) or not stripped):
                import_lines.append(line)
            else:
                other_lines.append(line)
        
        # Réorganisation des imports : standard, tiers, locaux
        organized_imports = self._organize_imports(import_lines)
        
        # Reconstruction du code
        if organized_imports:
            return '\n'.join(organized_imports + [''] + other_lines)
        else:
            return code

    def _organize_imports(self, import_lines: list) -> list:
        """Organise les imports par catégorie."""
        stdlib_imports = []
        third_party_imports = []
        local_imports = []
        
        for line in import_lines:
            stripped = line.strip()
            if not stripped or stripped.startswith('#'):
                continue
                
            # Classification basique des imports
            if 'from agent_factory' in stripped or 'from .' in stripped:
                local_imports.append(line)
            elif any(mod in stripped for mod in self.stdlib_modules):
                stdlib_imports.append(line)
            else:
                third_party_imports.append(line)
        
        # Assemblage final avec séparation
        organized = []
        
        if stdlib_imports:
            organized.extend(sorted(stdlib_imports))
            organized.append('')
        
        if third_party_imports:
            organized.extend(sorted(third_party_imports))
            organized.append('')
        
        if local_imports:
            organized.extend(sorted(local_imports))
        
        return organized
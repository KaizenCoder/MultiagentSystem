#!/usr/bin/env python3
"""API REST pour lancer les agents de maintenance NextGeneration"""

from fastapi import FastAPI
import subprocess

app = FastAPI()

@app.get("/run/{agent_id}")
def run_agent(agent_id: int):
    agent_map = {
        1: "agent_MAINTENANCE_01_analyseur_structure.py",
        2: "agent_MAINTENANCE_02_evaluateur_utilite.py",
        3: "agent_MAINTENANCE_03_adaptateur_code.py",
        4: "agent_MAINTENANCE_04_testeur_anti_faux_agents.py",
        5: "agent_MAINTENANCE_05_documenteur_peer_reviewer.py",
        6: "agent_MAINTENANCE_06_validateur_final.py",
    }
    script = agent_map.get(agent_id)
    if not script:
        return {"error": "Agent non trouvé"}
    subprocess.Popen(["python", script])
    return {"status": "Agent lancé", "agent": script}

#!/usr/bin/env python3
"""Orchestrateur async pour l’équipe de maintenance NextGeneration"""

import asyncio
import subprocess

AGENTS = [
    "agent_MAINTENANCE_01_analyseur_structure.py",
    "agent_MAINTENANCE_02_evaluateur_utilite.py",
    "agent_MAINTENANCE_03_adaptateur_code.py",
    "agent_MAINTENANCE_04_testeur_anti_faux_agents.py",
    "agent_MAINTENANCE_05_documenteur_peer_reviewer.py",
    "agent_MAINTENANCE_06_validateur_final.py",
]

async def run_agent(script):
    proc = await asyncio.create_subprocess_exec("python", script)
    await proc.wait()

async def main():
    tasks = [run_agent(agent) for agent in AGENTS]
    await asyncio.gather(*tasks)

if __name__ == "__main__":
    asyncio.run(main())

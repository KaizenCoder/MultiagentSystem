#!/usr/bin/env python3
"""
Agent 5 - Documenteur
Modèle: Gemini 2.0 Flash
Mission: Documentation complète des outils et agents
Équipe: NextGeneration Tools Migration
"""

import asyncio
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Any, Optional

# Configuration des logs
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)

class Agent5Documenteur:
    """Agent 5 - Documenteur avec Gemini 2.0 Flash"""
    
    def __init__(self, resultats_tests: Dict[str, Any], target_path: str, workspace_path: str):
        self.resultats_tests = resultats_tests
        self.target_path = Path(target_path)
        self.workspace_path = Path(workspace_path)
        self.agent_id = f"agent_5_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        self.agent_type = "documenteur"
        self.logger = logging.getLogger("Agent5Documenteur")
        
        # Statistiques
        self.documents_generes = []
        self.guides_crees = []
        self.schemas_documentes = []
        
        self.logger.info(f"🔍 Agent 5 Documenteur initialisé - ID: {self.agent_id}")
        
    async def startup(self):
        """Démarrage Agent 5 Documenteur"""
        self.logger.info(f"🚀 Agent 5 Documenteur {self.agent_id} - DÉMARRAGE")
        
        # Vérification des chemins
        if not self.target_path.exists():
            self.logger.warning(f"⚠️ Chemin cible non trouvé: {self.target_path}")
            self.target_path.mkdir(parents=True, exist_ok=True)
        
        # Créer les répertoires de documentation
        docs_dirs = [
            self.workspace_path / "docs",
            self.workspace_path / "docs" / "agents",
            self.workspace_path / "docs" / "guides",
            self.workspace_path / "docs" / "schemas"
        ]
        
        for docs_dir in docs_dirs:
            docs_dir.mkdir(parents=True, exist_ok=True)
        
        self.logger.info("✅ Agent 5 Documenteur prêt")
        
    async def shutdown(self):
        """Arrêt Agent 5 Documenteur"""
        self.logger.info(f"🛑 Agent 5 Documenteur {self.agent_id} - ARRÊT")
        
    async def documenter_complete(self) -> Dict[str, Any]:
        """Documentation complète de la mission"""
        self.logger.info("📚 AGENT 5 - Démarrage documentation complète")
        
        start_time = datetime.now()
        resultats = {
            "agent_id": self.agent_id,
            "agent_type": self.agent_type,
            "mission": "documentation_complete",
            "timestamp_debut": start_time.isoformat(),
            "target_path": str(self.target_path),
            "workspace_path": str(self.workspace_path),
            "documents_generes": [],
            "guides_crees": [],
            "schemas_documentes": [],
            "status": "en_cours"
        }
        
        try:
            # 1. Documenter les agents analysés
            await self._documenter_agents()
            
            # 2. Créer les guides d'utilisation
            await self._creer_guides_utilisation()
            
            # 3. Documenter les schémas et architectures
            await self._documenter_schemas()
            
            # 4. Créer la documentation consolidée
            await self._creer_documentation_consolidee()
            
            # 5. Générer l'index de documentation
            await self._generer_index_documentation()
            
            # Finalisation
            end_time = datetime.now()
            duree = (end_time - start_time).total_seconds()
            
            resultats.update({
                "status": "complete",
                "timestamp_fin": end_time.isoformat(),
                "duree_sec": duree,
                "documents_generes": self.documents_generes,
                "guides_crees": self.guides_crees,
                "schemas_documentes": self.schemas_documentes,
                "nombre_documents": len(self.documents_generes),
                "statistiques": {
                    "agents_documentes": len(self.schemas_documentes),
                    "guides_crees": len(self.guides_crees),
                    "documentation_consolidee": True
                }
            })
            
            # Sauvegarde rapport
            await self._sauvegarder_rapport(resultats)
            
            self.logger.info(f"📚 AGENT 5 - Documentation terminée en {duree:.1f}s")
            self.logger.info(f"   📄 Documents générés: {len(self.documents_generes)}")
            self.logger.info(f"   📖 Guides créés: {len(self.guides_crees)}")
            self.logger.info(f"   🏗️ Schémas documentés: {len(self.schemas_documentes)}")
            
            return resultats
            
        except Exception as e:
            self.logger.error(f"❌ Erreur documentation: {e}")
            resultats.update({
                "status": "erreur",
                "erreur": str(e),
                "timestamp_erreur": datetime.now().isoformat()
            })
            return resultats
    
    async def _documenter_agents(self):
        """Documenter tous les agents analysés"""
        self.logger.info("📋 Documentation des agents...")
        
        # Scan des agents dans le répertoire cible
        agents_trouves = []
        if self.target_path.exists():
            for agent_file in self.target_path.glob("agent_*.py"):
                if agent_file.name not in ["__init__.py"]:
                    agents_trouves.append(agent_file)
        
        # Documentation de chaque agent
        for agent_file in agents_trouves:
            await self._documenter_agent_unique(agent_file)
        
        self.logger.info(f"✅ {len(agents_trouves)} agents documentés")
        
    async def _documenter_agent_unique(self, agent_file: Path):
        """Documenter un agent unique"""
        try:
            nom_agent = agent_file.stem
            self.logger.info(f"📝 Documentation de {nom_agent}...")
            
            # Lire le fichier agent
            with open(agent_file, 'r', encoding='utf-8') as f:
                contenu = f.read()
            
            # Extraire les informations
            info_agent = self._extraire_info_agent(contenu, nom_agent)
            
            # Créer la documentation
            doc_content = self._generer_doc_agent(info_agent)
            
            # Sauvegarder
            doc_path = self.workspace_path / "docs" / "agents" / f"{nom_agent}_documentation.md"
            with open(doc_path, 'w', encoding='utf-8') as f:
                f.write(doc_content)
            
            self.documents_generes.append(str(doc_path))
            self.schemas_documentes.append(nom_agent)
            
        except Exception as e:
            self.logger.error(f"❌ Erreur documentation {agent_file.name}: {e}")
    
    def _extraire_info_agent(self, contenu: str, nom_agent: str) -> Dict[str, Any]:
        """Extraire les informations d'un agent"""
        info = {
            "nom": nom_agent,
            "description": "Agent NextGeneration",
            "modele": "Unknown",
            "mission": "Mission non définie",
            "classes": [],
            "fonctions": [],
            "imports": []
        }
        
        # Extraction basique des informations
        lignes = contenu.split('\n')
        
        for ligne in lignes:
            ligne_clean = ligne.strip()
            
            # Extraire la mission depuis le docstring
            if "Mission:" in ligne_clean:
                info["mission"] = ligne_clean.split("Mission:")[-1].strip()
            
            # Extraire le modèle
            if "Modèle:" in ligne_clean:
                info["modele"] = ligne_clean.split("Modèle:")[-1].strip()
            
            # Extraire les classes
            if ligne_clean.startswith("class "):
                classe = ligne_clean.split("class ")[1].split("(")[0].split(":")[0]
                info["classes"].append(classe)
            
            # Extraire les fonctions
            if ligne_clean.startswith("def ") or ligne_clean.startswith("async def "):
                fonction = ligne_clean.split("def ")[1].split("(")[0]
                info["fonctions"].append(fonction)
            
            # Extraire les imports
            if ligne_clean.startswith("import ") or ligne_clean.startswith("from "):
                info["imports"].append(ligne_clean)
        
        return info
    
    def _generer_doc_agent(self, info: Dict[str, Any]) -> str:
        """Générer la documentation d'un agent"""
        doc = f"""# 📋 Documentation Agent: {info['nom']}

## 🎯 Informations Générales

- **Nom**: {info['nom']}
- **Modèle**: {info['modele']}
- **Mission**: {info['mission']}
- **Type**: Agent NextGeneration

## 🏗️ Architecture

### Classes Principales
{chr(10).join(f"- `{classe}`" for classe in info['classes'])}

### Fonctions Clés
{chr(10).join(f"- `{fonction}()`" for fonction in info['fonctions'][:10])}

## 📦 Dépendances

### Imports
```python
{chr(10).join(info['imports'][:5])}
```

## 🚀 Utilisation

### Instanciation
```python
agent = {info['classes'][0] if info['classes'] else 'Agent'}()
```

### Exécution
```python
# Démarrage
await agent.startup()

# Exécution mission
resultats = await agent.mission_principale()

# Arrêt
await agent.shutdown()
```

## 📊 Métriques

- **Classes définies**: {len(info['classes'])}
- **Fonctions disponibles**: {len(info['fonctions'])}
- **Modules importés**: {len(info['imports'])}

## 📝 Notes

Cette documentation a été générée automatiquement par l'Agent 5 Documenteur.

---
*Généré le {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} par Agent 5 Documenteur*
"""
        return doc
    
    async def _creer_guides_utilisation(self):
        """Créer les guides d'utilisation"""
        self.logger.info("📖 Création des guides d'utilisation...")
        
        guides = [
            ("guide_demarrage", self._creer_guide_demarrage),
            ("guide_maintenance", self._creer_guide_maintenance),
            ("guide_troubleshooting", self._creer_guide_troubleshooting)
        ]
        
        for nom_guide, fonction_creation in guides:
            try:
                contenu_guide = fonction_creation()
                guide_path = self.workspace_path / "docs" / "guides" / f"{nom_guide}.md"
                
                with open(guide_path, 'w', encoding='utf-8') as f:
                    f.write(contenu_guide)
                
                self.guides_crees.append(str(guide_path))
                self.logger.info(f"✅ Guide créé: {nom_guide}")
                
            except Exception as e:
                self.logger.error(f"❌ Erreur création guide {nom_guide}: {e}")
    
    def _creer_guide_demarrage(self) -> str:
        """Créer le guide de démarrage"""
        return f"""# 🚀 Guide de Démarrage - Équipe Agents NextGeneration

## 🎯 Introduction

Bienvenue dans l'équipe d'agents NextGeneration ! Ce guide vous aide à démarrer rapidement.

## 📋 Prérequis

- Python 3.8+
- pip installé
- Accès au répertoire du projet

## ⚡ Démarrage Rapide

### 1. Installation
```bash
cd equipe_agents_tools_migration
pip install -r requirements.txt
```

### 2. Lancement du Chef d'Équipe
```bash
python agent_0_chef_equipe_coordinateur.py
```

### 3. Lancement d'un Agent Individuel
```bash
python agent_1_analyseur_structure.py
python agent_2_evaluateur_utilite.py
```

## 🛠️ Configuration

### Variables d'Environnement
- `NEXTGEN_DEBUG=true` : Mode debug
- `NEXTGEN_LOG_LEVEL=INFO` : Niveau de logging

### Chemins Importants
- **Agents source**: `../agent_factory_implementation/agents`
- **Workspace**: `./`
- **Rapports**: `./reports`

## 📊 Commandes Utiles

```bash
# Vérifier l'état de l'équipe
python agent_0_chef_equipe_coordinateur.py --help

# Analyser la structure
python agent_1_analyseur_structure.py --analyze

# Évaluer l'utilité
python agent_2_evaluateur_utilite.py --evaluate
```

---
*Créé par Agent 5 Documenteur - {datetime.now().strftime('%Y-%m-%d')}*
"""
    
    def _creer_guide_maintenance(self) -> str:
        """Créer le guide de maintenance"""
        return f"""# 🔧 Guide de Maintenance - Équipe Agents

## 🎯 Maintenance Préventive

### Vérifications Quotidiennes
- [ ] État des agents (health check)
- [ ] Logs d'erreurs
- [ ] Espace disque disponible

### Vérifications Hebdomadaires
- [ ] Performance des agents
- [ ] Mise à jour des dépendances
- [ ] Nettoyage des logs anciens

## 🚨 Résolution de Problèmes

### Problèmes Courants

#### Agent ne démarre pas
```bash
# Vérifier les dépendances
pip check

# Vérifier les permissions
ls -la agent_*.py

# Réinstaller les dépendances
pip install -r requirements.txt --force-reinstall
```

#### Erreurs d'import
```bash
# Vérifier PYTHONPATH
echo $PYTHONPATH

# Ajouter le répertoire courant
export PYTHONPATH=$PYTHONPATH:.
```

### Logs et Diagnostic
- **Logs**: `./logs/`
- **Rapports**: `./reports/`
- **Debug**: Utiliser `--debug` ou `NEXTGEN_DEBUG=true`

## 🔄 Maintenance Automatisée

### Scripts de Maintenance
```bash
# Maintenance complète
python agent_0_chef_equipe_coordinateur.py --maintenance

# Nettoyage
python maintenance_scripts/cleanup.py

# Sauvegarde
python maintenance_scripts/backup.py
```

---
*Créé par Agent 5 Documenteur - {datetime.now().strftime('%Y-%m-%d')}*
"""
    
    def _creer_guide_troubleshooting(self) -> str:
        """Créer le guide de troubleshooting"""
        return f"""# 🔍 Guide de Troubleshooting - Agents NextGeneration

## ❌ Erreurs Fréquentes

### 1. ImportError: No module named 'agent_X'
**Cause**: Module non trouvé
**Solution**:
```bash
# Vérifier le répertoire
ls -la agent_*.py

# Vérifier PYTHONPATH
export PYTHONPATH=$PYTHONPATH:.

# Réinstaller
pip install -r requirements.txt
```

### 2. AttributeError: 'Agent' object has no attribute 'startup'
**Cause**: Interface agent incompatible
**Solution**: Vérifier que l'agent implémente les bonnes méthodes

### 3. FileNotFoundError: Target path not found
**Cause**: Chemin cible incorrect
**Solution**:
```bash
# Créer les répertoires
mkdir -p ../agent_factory_implementation/agents
mkdir -p reports
```

## 🔧 Commandes de Diagnostic

### Test des Agents
```bash
# Test complet
python agent_0_chef_equipe_coordinateur.py --test

# Test individuel
python agent_1_analyseur_structure.py --test
```

### Vérification des Chemins
```bash
# Vérifier la configuration
python -c "from pathlib import Path; print(Path('../agent_factory_implementation/agents').exists())"
```

### Logs Détaillés
```bash
# Mode verbose
python agent_0_chef_equipe_coordinateur.py --verbose

# Logs en temps réel
tail -f logs/*.log
```

## 📞 Support

### Informations à Fournir
1. Version Python: `python --version`
2. Système: `uname -a` (Linux/Mac) ou `systeminfo` (Windows)
3. Logs d'erreur complets
4. Commande exacte exécutée

### Contacts
- Documentation: `docs/`
- Issues: Repository GitHub
- Logs: `logs/troubleshooting_*.log`

---
*Créé par Agent 5 Documenteur - {datetime.now().strftime('%Y-%m-%d')}*
"""
    
    async def _documenter_schemas(self):
        """Documenter les schémas et architectures"""
        self.logger.info("🏗️ Documentation des schémas...")
        
        schema_doc = f"""# 🏗️ Architecture - Équipe Agents NextGeneration

## 📋 Vue d'Ensemble

L'équipe est composée de 7 agents spécialisés coordonnés par un chef d'équipe.

```
Agent 0 (Chef d'Équipe)
├── Agent 1 (Analyseur Structure)
├── Agent 2 (Évaluateur Utilité)
├── Agent 3 (Adaptateur Code)
├── Agent 4 (Testeur Intégration)
├── Agent 5 (Documenteur)
└── Agent 6 (Validateur Final)
```

## 🔄 Workflow de Mission

1. **Agent 0** coordonne l'ensemble
2. **Agent 1** analyse la structure des agents
3. **Agent 2** évalue l'utilité des agents
4. **Agent 3** adapte le code si nécessaire
5. **Agent 4** teste l'intégration
6. **Agent 5** génère la documentation
7. **Agent 6** valide la mission

## 📊 Interfaces et Protocoles

### Interface Agent Standard
```python
class AgentInterface:
    def __init__(self, target_path, workspace_path):
        self.agent_id = str
        self.agent_type = str
        self.logger = Logger
    
    async def startup(self):
        pass
    
    async def shutdown(self):
        pass
    
    async def health_check(self) -> Dict:
        pass
```

### Protocole de Communication
- **Input**: Configuration et données d'entrée
- **Processing**: Traitement asynchrone
- **Output**: Résultats structurés en JSON
- **Logging**: Logs détaillés pour monitoring

## 🗄️ Structure des Données

### Format des Résultats
```json
{{
  "agent_id": "agent_X_timestamp",
  "agent_type": "type_agent", 
  "status": "complete|erreur|en_cours",
  "resultats": {{}},
  "timestamp_debut": "ISO_8601",
  "timestamp_fin": "ISO_8601",
  "duree_sec": float
}}
```

---
*Généré par Agent 5 Documenteur - {datetime.now().strftime('%Y-%m-%d')}*
"""
        
        schema_path = self.workspace_path / "docs" / "schemas" / "architecture.md"
        with open(schema_path, 'w', encoding='utf-8') as f:
            f.write(schema_doc)
        
        self.documents_generes.append(str(schema_path))
        self.logger.info("✅ Schéma d'architecture documenté")
    
    async def _creer_documentation_consolidee(self):
        """Créer la documentation consolidée"""
        self.logger.info("📚 Création documentation consolidée...")
        
        readme_content = f"""# 📚 Documentation Équipe Agents NextGeneration

## 🎯 Vue d'Ensemble

Cette équipe d'agents spécialisés assure la maintenance et l'optimisation des agents NextGeneration.

## 📋 Agents Disponibles

- **[Agent 0](agents/agent_0_chef_equipe_coordinateur_documentation.md)** - Chef d'Équipe Coordinateur
- **[Agent 1](agents/agent_1_analyseur_structure_documentation.md)** - Analyseur Structure  
- **[Agent 2](agents/agent_2_evaluateur_utilite_documentation.md)** - Évaluateur Utilité
- **[Agent 3](agents/agent_3_adaptateur_code_documentation.md)** - Adaptateur Code
- **[Agent 4](agents/agent_4_testeur_integration_documentation.md)** - Testeur Intégration
- **[Agent 5](agents/agent_5_documenteur_documentation.md)** - Documenteur
- **[Agent 6](agents/agent_6_validateur_final_documentation.md)** - Validateur Final

## 📖 Guides

- **[Guide de Démarrage](guides/guide_demarrage.md)** - Premiers pas
- **[Guide de Maintenance](guides/guide_maintenance.md)** - Maintenance quotidienne
- **[Guide de Troubleshooting](guides/guide_troubleshooting.md)** - Résolution de problèmes

## 🏗️ Architecture

- **[Schémas d'Architecture](schemas/architecture.md)** - Vue technique détaillée

## 🚀 Démarrage Rapide

```bash
# Lancer le chef d'équipe
python agent_0_chef_equipe_coordinateur.py

# Workflow complet
python agent_0_chef_equipe_coordinateur.py --workflow-complet
```

## 📊 Statistiques

- **Agents**: {len([f for f in self.target_path.glob('agent_*.py') if f.name != '__init__.py'])} agents disponibles
- **Documentation**: {len(self.documents_generes)} documents générés
- **Guides**: {len(self.guides_crees)} guides créés

---
*Documentation générée automatiquement par Agent 5 Documenteur le {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}*
"""
        
        readme_path = self.workspace_path / "docs" / "README.md"
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(readme_content)
        
        self.documents_generes.append(str(readme_path))
        self.logger.info("✅ Documentation consolidée créée")
    
    async def _generer_index_documentation(self):
        """Générer l'index de la documentation"""
        self.logger.info("📇 Génération index documentation...")
        
        index_content = f"""# 📇 Index de la Documentation

## 📊 Statistiques Générales

- **Date de génération**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
- **Documents totaux**: {len(self.documents_generes)}
- **Guides créés**: {len(self.guides_crees)}
- **Schémas documentés**: {len(self.schemas_documentes)}

## 📁 Structure des Fichiers

### Documents Générés
{chr(10).join(f"- `{Path(doc).name}`" for doc in self.documents_generes)}

### Guides Créés  
{chr(10).join(f"- `{Path(guide).name}`" for guide in self.guides_crees)}

### Agents Documentés
{chr(10).join(f"- {schema}" for schema in self.schemas_documentes)}

## 🔗 Liens Rapides

- **[Documentation Principale](README.md)**
- **[Guides](guides/)**
- **[Agents](agents/)**
- **[Schémas](schemas/)**

---
*Index généré par Agent 5 Documenteur*
"""
        
        index_path = self.workspace_path / "docs" / "INDEX.md"
        with open(index_path, 'w', encoding='utf-8') as f:
            f.write(index_content)
        
        self.documents_generes.append(str(index_path))
        self.logger.info("✅ Index documentation généré")
    
    async def _sauvegarder_rapport(self, resultats: Dict[str, Any]):
        """Sauvegarder le rapport de documentation"""
        try:
            reports_dir = self.workspace_path / "reports"
            reports_dir.mkdir(parents=True, exist_ok=True)
            
            rapport_path = reports_dir / f"agent_5_documentation_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            
            with open(rapport_path, 'w', encoding='utf-8') as f:
                json.dump(resultats, f, indent=2, ensure_ascii=False, default=str)
            
            self.logger.info(f"💾 Rapport sauvegardé: {rapport_path}")
            
        except Exception as e:
            self.logger.error(f"❌ Erreur sauvegarde rapport: {e}")

# Fonction factory pour compatibilité
def create_agent_5_documenteur(resultats_tests: Dict[str, Any], target_path: str, workspace_path: str):
    """Factory pour créer Agent 5 Documenteur"""
    return Agent5Documenteur(resultats_tests, target_path, workspace_path)

# Point d'entrée direct
async def main():
    """Point d'entrée principal Agent 5 Documenteur"""
    print("📚 AGENT 5 - DOCUMENTEUR")
    print("=" * 40)
    
    # Configuration par défaut
    resultats_tests = {"tests_effectues": True, "resultats": "simulation"}
    target_path = "../agent_factory_implementation/agents"
    workspace_path = "."
    
    try:
        # Création et exécution
        documenteur = create_agent_5_documenteur(resultats_tests, target_path, workspace_path)
        await documenteur.startup()
        
        # Lancement documentation
        resultats = await documenteur.documenter_complete()
        
        # Affichage résultats
        print(f"\n📊 RÉSULTATS:")
        print(f"Status: {resultats['status']}")
        if resultats['status'] == 'complete':
            print(f"Documents générés: {resultats['nombre_documents']}")
            print(f"Durée: {resultats['duree_sec']:.1f}s")
        
        await documenteur.shutdown()
        print("✅ Agent 5 Documenteur terminé avec succès")
        
    except Exception as e:
        print(f"❌ Erreur: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    result = asyncio.run(main())
    exit(result) 
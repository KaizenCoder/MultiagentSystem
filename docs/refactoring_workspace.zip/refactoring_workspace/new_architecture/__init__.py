"""Module refactoring NextGeneration"""

"""Auth Deps - NextGeneration Refactored"""
# TODO: Implmenter

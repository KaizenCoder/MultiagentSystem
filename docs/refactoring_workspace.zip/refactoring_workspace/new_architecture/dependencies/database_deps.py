"""Database Deps - NextGeneration Refactored"""
# TODO: Implmenter

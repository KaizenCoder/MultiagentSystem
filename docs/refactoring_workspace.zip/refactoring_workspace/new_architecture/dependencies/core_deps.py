"""Core Deps - NextGeneration Refactored"""
# TODO: Implmenter

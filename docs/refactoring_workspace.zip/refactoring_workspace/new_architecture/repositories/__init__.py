"""Module repositories - NextGeneration Refactored"""

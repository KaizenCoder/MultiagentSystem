"""Module schemas - NextGeneration Refactored"""

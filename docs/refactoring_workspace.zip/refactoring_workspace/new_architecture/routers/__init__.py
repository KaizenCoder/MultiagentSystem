"""Module routers - NextGeneration Refactored"""

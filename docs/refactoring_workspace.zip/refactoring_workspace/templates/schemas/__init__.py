"""Module schemas - Refactoring NextGeneration"""

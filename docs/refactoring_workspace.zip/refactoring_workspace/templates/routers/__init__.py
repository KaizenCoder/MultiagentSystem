"""Module routers - Refactoring NextGeneration"""

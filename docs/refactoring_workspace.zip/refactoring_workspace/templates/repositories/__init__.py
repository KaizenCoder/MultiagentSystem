"""Module repositories - Refactoring NextGeneration"""

"""Module services - Refactoring NextGeneration"""
